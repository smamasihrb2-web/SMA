package ir.maaih.planner
import android.annotation.SuppressLint
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView

@SuppressLint("MissingPermission")
fun locate(c: Context, cb: (Double, Double) -> Unit) {
    LocationServices.getFusedLocationProviderClient(c).getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
        .addOnSuccessListener { l -> if (l != null) cb(l.latitude, l.longitude) }
}

@Composable fun MapPicker(lat0: Double, lng0: Double, onDone: (Double, Double) -> Unit, onCancel: () -> Unit) {
    val c = LocalContext.current
    var mv by remember { mutableStateOf<MapView?>(null) }
    LaunchedEffect(Unit) { locate(c) { la, lo -> mv?.controller?.setCenter(GeoPoint(la, lo)) } }
    DisposableEffect(Unit) { onDispose { mv?.onDetach() } }
    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color.White)) {
            AndroidView(factory = { ctx ->
                Configuration.getInstance().apply { userAgentValue = ctx.packageName; osmdroidBasePath = ctx.filesDir; osmdroidTileCache = java.io.File(ctx.cacheDir, "osm") }
                MapView(ctx).apply { setTileSource(TileSourceFactory.MAPNIK); setMultiTouchControls(true); controller.setZoom(17.0); controller.setCenter(GeoPoint(lat0, lng0)); mv = this }
            }, modifier = Modifier.fillMaxSize())
            Text("📍", fontSize = 38.sp, modifier = Modifier.align(Alignment.Center).offset(y = (-19).dp))
            Column(Modifier.align(Alignment.BottomCenter).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("نقشه رو جابه‌جا کن تا 📍 روی مکان دلخواه بیفته", Modifier.background(Color(0xCCFFFFFF)).padding(6.dp), fontSize = 12.sp)
                OutlinedButton({ locate(c) { la, lo -> mv?.controller?.animateTo(GeoPoint(la, lo)) } }, Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White)) { Text("🎯 موقعیت فعلی من", color = Ink) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button({ mv?.mapCenter?.let { onDone(it.latitude, it.longitude) } }, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Ink)) { Text("تأیید مکان") }
                    OutlinedButton(onCancel, Modifier.weight(1f), colors = ButtonDefaults.outlinedButtonColors(containerColor = Color.White)) { Text("انصراف", color = Ink) }
                }
            }
        }
    }
}
