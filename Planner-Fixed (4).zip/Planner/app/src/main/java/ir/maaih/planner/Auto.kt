package ir.maaih.planner
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.*
import android.net.Uri
import android.provider.DocumentsContract
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.*

object AutoBackup {
    private fun pi(c: Context) = PendingIntent.getBroadcast(c, 700, Intent(c, BackupReceiver::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun schedule(c: Context) {
        val p = Store.p(c)
        c.getSystemService(android.app.AlarmManager::class.java).cancel(pi(c))
        if (!p.getBoolean("ab_on", false) || p.getString("ab_uri", null) == null) return
        val m = p.getInt("ab_min", 1260)
        var t = LocalDate.now().atTime(m / 60, m % 60)
        if (!t.isAfter(LocalDateTime.now().plusSeconds(5))) t = t.plusDays(1)
        Alarms.schedule(c, t.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(), pi(c))
    }
    fun run(c: Context): Boolean {
        val p = Store.p(c)
        val uri = Uri.parse(p.getString("ab_uri", null) ?: return false)
        return try {
            val parent = DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri))
            val doc = DocumentsContract.createDocument(c.contentResolver, parent, "application/json", "planner-backup-" + LocalDate.now() + ".json") ?: return false
            c.contentResolver.openOutputStream(doc)!!.use { it.write(Store.backup(c).toByteArray()) }
            p.edit().putLong("ab_last", System.currentTimeMillis()).apply(); true
        } catch (e: Exception) { false }
    }
}

class BackupReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val p = Store.p(c)
        val weekly = p.getInt("ab_freq", 0) == 1
        if (!weekly || System.currentTimeMillis() - p.getLong("ab_last", 0L) > 561600000L) AutoBackup.run(c)
        AutoBackup.schedule(c)
    }
}

@Composable fun AutoBackupCard() {
    val c = LocalContext.current; val sp = Store.p(c)
    var on by remember { mutableStateOf(sp.getBoolean("ab_on", false)) }
    var uri by remember { mutableStateOf(sp.getString("ab_uri", null)) }
    var min by remember { mutableStateOf(sp.getInt("ab_min", 1260)) }
    var freq by remember { mutableStateOf(sp.getInt("ab_freq", 0)) }
    var last by remember { mutableStateOf(sp.getLong("ab_last", 0L)) }
    fun msg(t: String) = Toast.makeText(c, t, Toast.LENGTH_LONG).show()
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) {
            try { c.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (e: Exception) { }
            uri = u.toString(); sp.edit().putString("ab_uri", uri).apply(); AutoBackup.schedule(c)
        }
    }
    GradCard(Modifier.fillMaxWidth()) {
        Title("پشتیبان‌گیری خودکار")
        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("فعال باشه", Modifier.weight(1f))
            Switch(on, { v -> if (v && uri == null) msg("اول پوشه ذخیره رو انتخاب کن") else { on = v; sp.edit().putBoolean("ab_on", v).apply(); AutoBackup.schedule(c) } },
                colors = SwitchDefaults.colors(checkedTrackColor = Ink, checkedThumbColor = androidx.compose.ui.graphics.Color.White))
        }
        OutlinedButton({ pick.launch(null) }, Modifier.fillMaxWidth().padding(top = 6.dp)) {
            Text("📁 " + (uri?.let { Uri.decode(Uri.parse(it).lastPathSegment ?: "") } ?: "انتخاب پوشه ذخیره"), color = Ink, maxLines = 1) }
        OutlinedButton({ TimePickerDialog(c, { _, h, m -> min = h * 60 + m; sp.edit().putInt("ab_min", min).apply(); AutoBackup.schedule(c) }, min / 60, min % 60, true).show() },
            Modifier.fillMaxWidth()) { Text("⏰ ساعت پشتیبان‌گیری: " + Jalali.fa("%02d:%02d".format(min / 60, min % 60)), color = Ink) }
        Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("روزانه", "هفتگی").forEachIndexed { i, s -> FilterChip(freq == i, { freq = i; sp.edit().putInt("ab_freq", i).apply() }, { Text(s) }) }
        }
        Button({ if (AutoBackup.run(c)) { last = sp.getLong("ab_last", 0L); msg("پشتیبان ساخته شد ✅") } else msg("پوشه رو انتخاب کن یا دسترسی رو دوباره بده") },
            Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Ink)) { Text("همین الان پشتیبان بگیر") }
        if (last > 0) Text("آخرین پشتیبان: " + Jalali.fmt(last), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    }
}
