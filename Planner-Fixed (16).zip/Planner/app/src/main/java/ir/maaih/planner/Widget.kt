package ir.maaih.planner
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.widget.RemoteViews

class ReminderWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { Store.cleanup(c); refresh(c) }
    override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            MODE -> { c.getSharedPreferences("w", 0).edit().putInt("mode", i.getIntExtra("mode", 0)).apply(); refresh(c) }
            TOGGLE -> { val id = i.getLongExtra("i", 0); val r = Store.reminders(c).find { it.id == id }; if (r != null) Store.setDone(c, id, !r.done); refresh(c) }
            REFRESH -> { Store.cleanup(c); refresh(c) }
            else -> super.onReceive(c, i)
        }
    }
    companion object {
        const val MODE = "ir.maaih.planner.MODE"
        const val TOGGLE = "ir.maaih.planner.TOGGLE"
        const val REFRESH = "ir.maaih.planner.REFRESH"
        fun scheduleHide(c: Context) {
            val pi = PendingIntent.getBroadcast(c, 400, Intent(c, ReminderWidget::class.java).setAction(REFRESH), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            Alarms.schedule(c, System.currentTimeMillis() + 62000, pi)
        }
        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, ReminderWidget::class.java)); if (ids.isEmpty()) return
            val mode = c.getSharedPreferences("w", 0).getInt("mode", 0)
            val (f, t) = rangeOf(mode, 0); val now = System.currentTimeMillis()
            val items = Store.occurrences(Store.reminders(c), f.ms(), t.ms()).filter { o -> o.r.trig == 0 && o.r.repeat == 0 && (!(o.first && o.r.done) || now - o.r.doneAt < 60000) }
            val rv = RemoteViews(c.packageName, R.layout.widget)
            rv.setTextViewText(R.id.w_title, Jalali.label(mode, f, t))
            val rows = intArrayOf(R.id.r0, R.id.r1, R.id.r2, R.id.r3, R.id.r4, R.id.r5, R.id.r6, R.id.r7)
            val cbs = intArrayOf(R.id.cb0, R.id.cb1, R.id.cb2, R.id.cb3, R.id.cb4, R.id.cb5, R.id.cb6, R.id.cb7)
            val ts = intArrayOf(R.id.t0, R.id.t1, R.id.t2, R.id.t3, R.id.t4, R.id.t5, R.id.t6, R.id.t7)
            for (k in 0 until 8) {
                val o = items.getOrNull(k)
                if (o == null) { rv.setViewVisibility(rows[k], View.GONE); continue }
                rv.setViewVisibility(rows[k], View.VISIBLE)
                val done = o.first && o.r.done; val overdue = !done && o.at < now
                val colr = if (done) 0xFF9E9E9E.toInt() else if (overdue) 0xFFD32F2F.toInt() else 0xFF222222.toInt()
                rv.setTextViewText(cbs[k], if (!o.first) "▫" else if (done) "☑" else "☐")
                rv.setTextViewText(ts[k], (if (mode == 0) Jalali.time(o.at) else Jalali.fmt(o.at)) + "  " + o.r.title + (if (mode == 0) "" else "  ⏳ " + Jalali.rel(o.at)))
                rv.setTextColor(ts[k], colr); rv.setTextColor(cbs[k], colr)
                if (o.first) rv.setOnClickPendingIntent(cbs[k], PendingIntent.getBroadcast(c, 500 + k,
                    Intent(c, ReminderWidget::class.java).setAction(TOGGLE).putExtra("i", o.r.id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
                else rv.setOnClickPendingIntent(cbs[k], null)

                // Tap reminder to edit
                rv.setOnClickPendingIntent(ts[k], PendingIntent.getActivity(c, 700 + k,
                    Intent(c, MainActivity::class.java).putExtra("edit_id", o.r.id)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            }
            val foot = (if (items.isEmpty()) "یادآوری‌ای نیست ✨" else "") + (if (items.size > 8) "  + " + Jalali.fa(items.size - 8) + " مورد دیگر" else "")
            rv.setTextViewText(R.id.w_text, foot.trim())
            val tabs = intArrayOf(R.id.w_m0, R.id.w_m1, R.id.w_m2)
            for (k in 0..2) {
                rv.setInt(tabs[k], "setBackgroundResource", if (k == mode) R.drawable.tab_on else R.drawable.tab_off)
                rv.setTextColor(tabs[k], if (k == mode) Color.WHITE else Color.BLACK)
                rv.setOnClickPendingIntent(tabs[k], PendingIntent.getBroadcast(c, 100 + k,
                    Intent(c, ReminderWidget::class.java).setAction(MODE).putExtra("mode", k), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
            }
            rv.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE))
            ids.forEach { m.updateAppWidget(it, rv) }
        }
    }
}
