package ir.maaih.planner

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import org.json.JSONObject
import java.time.LocalDate

class WeatherWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) {
        refresh(c)
    }

    companion object {
        fun refresh(c: Context) {
            val m = AppWidgetManager.getInstance(c)
            val ids = m.getAppWidgetIds(ComponentName(c, WeatherWidget::class.java))
            if (ids.isEmpty()) return

            val rv = RemoteViews(c.packageName, R.layout.widget_weather)
            val today = LocalDate.now()
            val shamsiDate = Jalali.fmtShort(today)

            rv.setTextViewText(R.id.weather_date, shamsiDate)

            // Read cached weather from app SharedPreferences
            val cacheStr = Store.p(c).getString("weather_cache", null)
            if (!cacheStr.isNullOrEmpty()) {
                try {
                    val o = JSONObject(cacheStr)
                    val cityName = o.optString("city", "تهران")
                    val temp = o.optInt("temp", 22)
                    val cond = o.optJSONObject("condition")
                    val condTitle = cond?.optString("title", "صاف و آفتابی") ?: "صاف و آفتابی"
                    val condIcon = cond?.optString("icon", "☀️") ?: "☀️"
                    val humidity = o.optInt("humidity", 35)
                    val wind = o.optInt("windSpeed", 12)

                    rv.setTextViewText(R.id.weather_city, "آب و هوای $cityName")
                    rv.setTextViewText(R.id.weather_temp_main, Jalali.fa("$temp°"))
                    rv.setTextViewText(R.id.weather_icon_main, condIcon)
                    rv.setTextViewText(R.id.weather_desc, condTitle)
                    rv.setTextViewText(R.id.weather_details, "رطوبت: ${Jalali.fa("$humidity٪")} • باد: ${Jalali.fa("$wind")} کیلومتر")

                    // Hourly forecast if available
                    val hourly = o.optJSONArray("hourly")
                    if (hourly != null && hourly.length() >= 4) {
                        val times = intArrayOf(R.id.fc_time_0, R.id.fc_time_1, R.id.fc_time_2, R.id.fc_time_3)
                        val icons = intArrayOf(R.id.fc_icon_0, R.id.fc_icon_1, R.id.fc_icon_2, R.id.fc_icon_3)
                        val temps = intArrayOf(R.id.fc_temp_0, R.id.fc_temp_1, R.id.fc_temp_2, R.id.fc_temp_3)

                        for (k in 0..3) {
                            val hObj = hourly.getJSONObject(k)
                            val tLabel = hObj.optString("time", "—")
                            val tIcon = hObj.optJSONObject("condition")?.optString("icon", "☀️") ?: "☀️"
                            val tTemp = hObj.optInt("temp", 20)

                            rv.setTextViewText(times[k], Jalali.fa(tLabel))
                            rv.setTextViewText(icons[k], tIcon)
                            rv.setTextViewText(temps[k], Jalali.fa("$tTemp°"))
                        }
                    }
                } catch (e: Exception) {
                    android.util.Log.e("SMA_WEATHER_WIDGET", "Error parsing weather: ${e.message}")
                }
            } else {
                rv.setTextViewText(R.id.weather_city, "آب و هوای تهران")
                rv.setTextViewText(R.id.weather_temp_main, Jalali.fa("۲۲°"))
                rv.setTextViewText(R.id.weather_icon_main, "☀️")
                rv.setTextViewText(R.id.weather_desc, "صاف و آفتابی")
                rv.setTextViewText(R.id.weather_details, "رطوبت: ۳۵٪ • باد: ۱۲ کیلومتر")
            }

            // Click to open main app
            rv.setOnClickPendingIntent(
                R.id.w_weather_root,
                PendingIntent.getActivity(c, 888, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            )

            ids.forEach { m.updateAppWidget(it, rv) }
        }
    }
}
