package ir.maaih.planner
import android.Manifest
import android.annotation.SuppressLint
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import java.time.*

object Notifs {
    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("rem", "یادآوری‌ها", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("mood", "حال و هوا", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(NotificationChannel("date_bar", "تقویم و تاریخ روزانه", NotificationManager.IMPORTANCE_LOW).apply {
            description = "نمایش تاریخ شمسی، میلادی و قمری در پرده بالایی گوشی"
            setShowBadge(false)
        })
    }
    fun openChannel(c: Context, id: String) {
        channels(c)
        c.startActivity(Intent(Settings.ACTION_CHANNEL_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName).putExtra(Settings.EXTRA_CHANNEL_ID, id).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    fun openApp(c: Context) = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
    fun action(c: Context, code: Int, label: String, cls: Class<*>, id: Long, a: String): NotificationCompat.Action {
        val pi = PendingIntent.getBroadcast(c, code, Intent(c, cls).putExtra("i", id).putExtra("a", a), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Action.Builder(0, label, pi).build()
    }
    fun post(c: Context, chan: String, id: Int, title: String, body: String, content: PendingIntent, icon: Int,
             actions: List<NotificationCompat.Action> = emptyList(), big: RemoteViews? = null, full: PendingIntent? = null, auto: Boolean = true) {
        channels(c)
        val rv = RemoteViews(c.packageName, R.layout.notif_card).apply { setImageViewBitmap(R.id.n_img, Card.bitmap(c, title, body)) }
        val b = NotificationCompat.Builder(c, chan).setSmallIcon(icon).setContentTitle(title).setContentText(body)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle()).setCustomContentView(rv).setCustomHeadsUpContentView(rv).setCustomBigContentView(big ?: rv)
            .setAutoCancel(auto).setContentIntent(content).setPriority(NotificationCompat.PRIORITY_HIGH)
        actions.forEach { b.addAction(it) }
        if (full != null) b.setFullScreenIntent(full, true)
        c.getSystemService(NotificationManager::class.java).notify(id, b.build())
    }
    fun postLocationAlert(c: Context, nid: Int, title: String, body: String, reminderId: Long, rc: Int) {
        channels(c)
        val openApp = PendingIntent.getActivity(
            c, rc,
            Intent(c, MainActivity::class.java).putExtra("edit_id", reminderId)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val donePi = PendingIntent.getBroadcast(
            c, rc + 1,
            Intent(c, GeoActionReceiver::class.java).putExtra("i", reminderId).putExtra("a", "done"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val againPi = PendingIntent.getBroadcast(
            c, rc + 2,
            Intent(c, GeoActionReceiver::class.java).putExtra("i", reminderId).putExtra("a", "again"),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val rv = RemoteViews(c.packageName, R.layout.notif_card).apply {
            setImageViewBitmap(R.id.n_img, Card.bitmap(c, title, body))
        }
        val b = NotificationCompat.Builder(c, "rem")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setCustomContentView(rv)
            .setCustomHeadsUpContentView(rv)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setVibrate(longArrayOf(0, 500, 250, 500, 250, 500))
            .setAutoCancel(false)
            .setContentIntent(openApp)
            .setFullScreenIntent(openApp, true)
            .addAction(android.R.drawable.checkbox_on_background, "✅ انجام شد", donePi)
            .addAction(android.R.drawable.ic_menu_rotate, "🔁 دوباره یادآوری کن", againPi)

        c.getSystemService(NotificationManager::class.java).notify(nid, b.build())
    }
}

object Alarms {
    fun schedule(c: Context, at: Long, pi: PendingIntent) {
        val am = c.getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }
    private fun pi(c: Context, r: Reminder) = PendingIntent.getBroadcast(c, (r.id % Int.MAX_VALUE).toInt(),
        Intent(c, AlarmReceiver::class.java).putExtra("i", r.id), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun set(c: Context, r: Reminder) {
        if (r.at <= System.currentTimeMillis() || (r.done && r.repeat == 0)) return
        schedule(c, r.at, pi(c, r))
    }
    fun cancel(c: Context, r: Reminder) = c.getSystemService(AlarmManager::class.java).cancel(pi(c, r))
    fun syncAll(c: Context) = Store.reminders(c).forEach { set(c, it) }
}

object MoodAlarms {
    private fun pi(c: Context, m: Int) = PendingIntent.getBroadcast(c, 900000 + m,
        Intent(c, MoodReceiver::class.java).putExtra("m", m), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    fun set(c: Context, m: Int) {
        var t = LocalDate.now().atTime(m / 60, m % 60)
        if (!t.isAfter(LocalDateTime.now().plusSeconds(5))) t = t.plusDays(1)
        Alarms.schedule(c, t.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli(), pi(c, m))
    }
    fun cancel(c: Context, m: Int) = c.getSystemService(AlarmManager::class.java).cancel(pi(c, m))
    fun syncAll(c: Context) = Store.moodTimes(c).forEach { set(c, it) }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("i", 0); val r = Store.reminders(c).find { it.id == id } ?: return
        if (!r.done) Notifs.post(c, "rem", System.nanoTime().toInt(), "⏰ " + r.title, Jalali.fmt(r.at), Notifs.openApp(c), android.R.drawable.ic_lock_idle_alarm)
        Store.advance(c, id); ReminderWidget.refresh(c)
    }
}

class MoodReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        MoodAlarms.set(c, i.getIntExtra("m", 0))
        val pi = PendingIntent.getActivity(c, 1, Intent(c, MoodPromptActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val title = "😊 الان حالت چطوره؟"; val body = "یکی از حالت‌ها رو انتخاب کن"
        val big = RemoteViews(c.packageName, R.layout.notif_mood)
        big.setImageViewBitmap(R.id.n_img, Card.bitmap(c, title, body))
        val ids = intArrayOf(R.id.n_m0, R.id.n_m1, R.id.n_m2, R.id.n_m3, R.id.n_m4)
        for (k in 0..4) big.setOnClickPendingIntent(ids[k], PendingIntent.getBroadcast(c, 2000 + k, Intent(c, MoodPickReceiver::class.java).putExtra("lv", k), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        Notifs.post(c, "mood", 777, title, body, pi, android.R.drawable.ic_dialog_info, big = big, full = pi)
    }
}

class MoodPickReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.addMood(c, LocalDate.now().toEpochDay(), i.getIntExtra("lv", 2))
        c.getSystemService(NotificationManager::class.java).cancel(777)
    }
}

object DateNotification {
    fun post(c: Context) {
        try {
            Notifs.channels(c)
            val today = LocalDate.now()
            val shamsiShort = Jalali.fmtShort(today)
            val shamsiFull = Jalali.fmtFull(today)
            val miladi = Jalali.fmtMiladi(today)
            val hijri = Jalali.fmtHijri(today)

            val openPi = PendingIntent.getActivity(
                c, 999, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            val b = NotificationCompat.Builder(c, "date_bar")
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("🗓️ $shamsiShort (${Jalali.dayName(today)})")
                .setContentText("خورشیدی: $shamsiFull | میلادی: $miladi | قمری: $hijri")
                .setStyle(
                    NotificationCompat.BigTextStyle()
                        .bigText("☀️ تاریخ خورشیدی (شمسی): $shamsiFull\n🌍 تاریخ میلادی: $miladi\n🌙 تاریخ هجری قمری: $hijri")
                        .setSummaryText("تقویم سه‌گانه پلنر")
                )
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setContentIntent(openPi)
                .setAutoCancel(false)

            c.getSystemService(NotificationManager::class.java).notify(9999, b.build())
        } catch (e: Exception) {
            android.util.Log.e("SMA_DATE_NOTIF", "Failed to post date notif: ${e.message}")
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Store.normalize(c); Store.reminders(c).forEach { Alarms.set(c, it) }; MoodAlarms.syncAll(c); Geo.syncAll(c); AutoBackup.schedule(c); ReminderWidget.refresh(c); ClockWidget.refresh(c); ClockWidget.scheduleNextTick(c); WeatherWidget.refresh(c); DateNotification.post(c); GeoChecker.checkCurrentLocation(c)
    }
}

object Geo {
    private fun pi(c: Context) = PendingIntent.getBroadcast(
        c, 5,
        Intent(c, GeoReceiver::class.java),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE
    )

    @SuppressLint("MissingPermission")
    fun add(c: Context, r: Reminder) {
        if (r.trig == 0 || r.done || r.lat == 0.0 || r.lng == 0.0 || c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        val safeRad = maxOf(50f, r.rad.toFloat())
        val g = Geofence.Builder()
            .setRequestId(r.id.toString())
            .setCircularRegion(r.lat, r.lng, safeRad)
            .setExpirationDuration(Geofence.NEVER_EXPIRE)
            .setNotificationResponsiveness(0)
            .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER or Geofence.GEOFENCE_TRANSITION_EXIT)
            .build()
        val req = GeofencingRequest.Builder()
            .setInitialTrigger(if (r.trig == 1) GeofencingRequest.INITIAL_TRIGGER_ENTER else 0)
            .addGeofence(g)
            .build()
        LocationServices.getGeofencingClient(c).addGeofences(req, pi(c))
    }

    fun remove(c: Context, r: Reminder) {
        try {
            LocationServices.getGeofencingClient(c).removeGeofences(listOf(r.id.toString()))
        } catch (e: Exception) {}
    }

    fun syncAll(c: Context) = Store.reminders(c).forEach { add(c, it) }
}

class GeoReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val e = GeofencingEvent.fromIntent(i) ?: return
        if (e.hasError()) {
            android.util.Log.e("SMA_GEO", "Geofence error: ${e.errorCode}")
            return
        }
        val tr = e.geofenceTransition
        e.triggeringGeofences?.forEach { g ->
            val r = Store.reminders(c).find { it.id.toString() == g.requestId } ?: return@forEach
            if (r.done) return@forEach
            val match = (r.trig == 1 && tr == Geofence.GEOFENCE_TRANSITION_ENTER) || (r.trig == 2 && tr == Geofence.GEOFENCE_TRANSITION_EXIT)
            if (match) {
                if (!r.armed) return@forEach
                Store.update(c, r.copy(armed = false, again = false))
                val nid = (r.id % 1000000000L).toInt()
                val rc = (r.id % 100000L).toInt() * 3
                val title = if (r.trig == 1) "📍 رسیدی به محدوده: ${r.title}" else "📍 از محدوده خارج شدی: ${r.title}"
                val body = "برای حذف دائم این یادآوری «انجام شد» را بزنید، یا «دوباره یادآوری کن» تا در نوبت بعدی مجدداً یادآوری شود."
                Notifs.postLocationAlert(c, nid, title, body, r.id, rc)
            } else {
                val opposite = (r.trig == 1 && tr == Geofence.GEOFENCE_TRANSITION_EXIT) || (r.trig == 2 && tr == Geofence.GEOFENCE_TRANSITION_ENTER)
                if (opposite && (r.again || !r.armed)) {
                    Store.update(c, r.copy(armed = true, again = false))
                }
            }
        }
    }
}

class GeoActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("i", 0L)
        val action = i.getStringExtra("a") ?: "done"
        val nid = (id % 1000000000L).toInt()
        c.getSystemService(NotificationManager::class.java).cancel(nid)
        val r = Store.reminders(c).find { it.id == id } ?: return

        if (action == "done") {
            Geo.remove(c, r)
            val updated = Store.reminders(c).filter { it.id != id }
            Store.saveReminders(c, updated)
            try {
                android.widget.Toast.makeText(c, "یادآوری مکانی انجام شد و حذف گردید", android.widget.Toast.LENGTH_SHORT).show()
                MainActivity.instance?.runOnUiThread {
                    MainActivity.instance?.webView?.evaluateJavascript(
                        "try { window.dispatchEvent(new CustomEvent('sma_delete_reminder', { detail: { id: '$id' } })); } catch(e){}", null
                    )
                }
            } catch (e: Exception) {}
        } else if (action == "again") {
            Store.update(c, r.copy(armed = false, again = true))
            val msg = if (r.trig == 1)
                "تنظیم شد: پس از خروج و ورود مجدد به این محدوده، دوباره یادآوری خواهد شد"
            else
                "تنظیم شد: پس از ورود و خروج مجدد از این محدوده، دوباره یادآوری خواهد شد"
            try {
                android.widget.Toast.makeText(c, msg, android.widget.Toast.LENGTH_LONG).show()
                MainActivity.instance?.runOnUiThread {
                    MainActivity.instance?.webView?.evaluateJavascript(
                        "try { window.dispatchEvent(new CustomEvent('sma_rearm_reminder', { detail: { id: '$id' } })); } catch(e){}", null
                    )
                }
            } catch (e: Exception) {}
        }
    }
}

object GeoChecker {
    @SuppressLint("MissingPermission")
    fun checkCurrentLocation(c: Context) {
        if (c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        try {
            val flpc = LocationServices.getFusedLocationProviderClient(c)
            flpc.lastLocation.addOnSuccessListener { loc ->
                if (loc != null) evaluateLocation(c, loc.latitude, loc.longitude)
            }
        } catch (e: Exception) {
            android.util.Log.e("SMA_GEO", "GeoChecker error: ${e.message}")
        }
    }

    fun evaluateLocation(c: Context, lat: Double, lng: Double) {
        val active = Store.reminders(c).filter { it.trig > 0 && !it.done && it.lat != 0.0 && it.lng != 0.0 }
        active.forEach { r ->
            val res = FloatArray(1)
            android.location.Location.distanceBetween(lat, lng, r.lat, r.lng, res)
            val dist = res[0]
            val radius = maxOf(50f, r.rad.toFloat())
            val isInside = dist <= radius

            if (r.trig == 1) { // Enter
                if (isInside && r.armed) {
                    Store.update(c, r.copy(armed = false, again = false))
                    val nid = (r.id % 1000000000L).toInt()
                    val rc = (r.id % 100000L).toInt() * 3
                    Notifs.postLocationAlert(
                        c, nid, "📍 رسیدی به محدوده: ${r.title}",
                        "برای حذف دائم این یادآوری «انجام شد» را بزنید، یا «دوباره یادآوری کن» تا در نوبت بعدی مجدداً یادآوری شود.",
                        r.id, rc
                    )
                } else if (!isInside && (r.again || !r.armed)) {
                    Store.update(c, r.copy(armed = true, again = false))
                }
            } else if (r.trig == 2) { // Exit
                if (!isInside && r.armed) {
                    Store.update(c, r.copy(armed = false, again = false))
                    val nid = (r.id % 1000000000L).toInt()
                    val rc = (r.id % 100000L).toInt() * 3
                    Notifs.postLocationAlert(
                        c, nid, "📍 از محدوده خارج شدی: ${r.title}",
                        "برای حذف دائم این یادآوری «انجام شد» را بزنید، یا «دوباره یادآوری کن» تا در نوبت بعدی مجدداً یادآوری شود.",
                        r.id, rc
                    )
                } else if (isInside && (r.again || !r.armed)) {
                    Store.update(c, r.copy(armed = true, again = false))
                }
            }
        }
    }
}
